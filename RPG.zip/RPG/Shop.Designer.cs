﻿namespace RPG
{
    partial class Shop
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Shop));
            this.pictureBox24 = new System.Windows.Forms.PictureBox();
            this.pictureBox25 = new System.Windows.Forms.PictureBox();
            this.pictureBox22 = new System.Windows.Forms.PictureBox();
            this.pictureBox23 = new System.Windows.Forms.PictureBox();
            this.pictureBox20 = new System.Windows.Forms.PictureBox();
            this.pictureBox21 = new System.Windows.Forms.PictureBox();
            this.pictureBox18 = new System.Windows.Forms.PictureBox();
            this.pictureBox19 = new System.Windows.Forms.PictureBox();
            this.pictureBox16 = new System.Windows.Forms.PictureBox();
            this.pictureBox17 = new System.Windows.Forms.PictureBox();
            this.pictureBox14 = new System.Windows.Forms.PictureBox();
            this.pictureBox15 = new System.Windows.Forms.PictureBox();
            this.pictureBox12 = new System.Windows.Forms.PictureBox();
            this.pictureBox13 = new System.Windows.Forms.PictureBox();
            this.pictureBox10 = new System.Windows.Forms.PictureBox();
            this.pictureBox11 = new System.Windows.Forms.PictureBox();
            this.pictureBox8 = new System.Windows.Forms.PictureBox();
            this.pictureBox9 = new System.Windows.Forms.PictureBox();
            this.pictureBox6 = new System.Windows.Forms.PictureBox();
            this.pictureBox7 = new System.Windows.Forms.PictureBox();
            this.pictureBox5 = new System.Windows.Forms.PictureBox();
            this.pictureBox4 = new System.Windows.Forms.PictureBox();
            this.pictureBox3 = new System.Windows.Forms.PictureBox();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.ShopAnimation = new System.Windows.Forms.PictureBox();
            this.ShopKeeperConversation = new System.Windows.Forms.RichTextBox();
            this.ItemDescription = new System.Windows.Forms.RichTextBox();
            this.tabControl1 = new System.Windows.Forms.TabControl();
            this.ShopItems = new System.Windows.Forms.TabPage();
            this.WeaponsSell = new System.Windows.Forms.TabPage();
            this.pictureBox46 = new System.Windows.Forms.PictureBox();
            this.pictureBox47 = new System.Windows.Forms.PictureBox();
            this.pictureBox48 = new System.Windows.Forms.PictureBox();
            this.pictureBox49 = new System.Windows.Forms.PictureBox();
            this.pictureBox50 = new System.Windows.Forms.PictureBox();
            this.pictureBox41 = new System.Windows.Forms.PictureBox();
            this.pictureBox42 = new System.Windows.Forms.PictureBox();
            this.pictureBox43 = new System.Windows.Forms.PictureBox();
            this.pictureBox44 = new System.Windows.Forms.PictureBox();
            this.pictureBox45 = new System.Windows.Forms.PictureBox();
            this.pictureBox36 = new System.Windows.Forms.PictureBox();
            this.pictureBox37 = new System.Windows.Forms.PictureBox();
            this.pictureBox38 = new System.Windows.Forms.PictureBox();
            this.pictureBox39 = new System.Windows.Forms.PictureBox();
            this.pictureBox40 = new System.Windows.Forms.PictureBox();
            this.pictureBox31 = new System.Windows.Forms.PictureBox();
            this.pictureBox32 = new System.Windows.Forms.PictureBox();
            this.pictureBox33 = new System.Windows.Forms.PictureBox();
            this.pictureBox34 = new System.Windows.Forms.PictureBox();
            this.pictureBox35 = new System.Windows.Forms.PictureBox();
            this.pictureBox26 = new System.Windows.Forms.PictureBox();
            this.pictureBox27 = new System.Windows.Forms.PictureBox();
            this.pictureBox28 = new System.Windows.Forms.PictureBox();
            this.pictureBox29 = new System.Windows.Forms.PictureBox();
            this.pictureBox30 = new System.Windows.Forms.PictureBox();
            this.ArmorSell = new System.Windows.Forms.TabPage();
            this.pictureBox71 = new System.Windows.Forms.PictureBox();
            this.pictureBox72 = new System.Windows.Forms.PictureBox();
            this.pictureBox73 = new System.Windows.Forms.PictureBox();
            this.pictureBox74 = new System.Windows.Forms.PictureBox();
            this.pictureBox75 = new System.Windows.Forms.PictureBox();
            this.pictureBox66 = new System.Windows.Forms.PictureBox();
            this.pictureBox67 = new System.Windows.Forms.PictureBox();
            this.pictureBox68 = new System.Windows.Forms.PictureBox();
            this.pictureBox69 = new System.Windows.Forms.PictureBox();
            this.pictureBox70 = new System.Windows.Forms.PictureBox();
            this.pictureBox61 = new System.Windows.Forms.PictureBox();
            this.pictureBox62 = new System.Windows.Forms.PictureBox();
            this.pictureBox63 = new System.Windows.Forms.PictureBox();
            this.pictureBox64 = new System.Windows.Forms.PictureBox();
            this.pictureBox65 = new System.Windows.Forms.PictureBox();
            this.pictureBox56 = new System.Windows.Forms.PictureBox();
            this.pictureBox57 = new System.Windows.Forms.PictureBox();
            this.pictureBox58 = new System.Windows.Forms.PictureBox();
            this.pictureBox59 = new System.Windows.Forms.PictureBox();
            this.pictureBox60 = new System.Windows.Forms.PictureBox();
            this.pictureBox51 = new System.Windows.Forms.PictureBox();
            this.pictureBox52 = new System.Windows.Forms.PictureBox();
            this.pictureBox53 = new System.Windows.Forms.PictureBox();
            this.pictureBox54 = new System.Windows.Forms.PictureBox();
            this.pictureBox55 = new System.Windows.Forms.PictureBox();
            this.AccessorySell = new System.Windows.Forms.TabPage();
            this.pictureBox96 = new System.Windows.Forms.PictureBox();
            this.pictureBox97 = new System.Windows.Forms.PictureBox();
            this.pictureBox98 = new System.Windows.Forms.PictureBox();
            this.pictureBox99 = new System.Windows.Forms.PictureBox();
            this.pictureBox100 = new System.Windows.Forms.PictureBox();
            this.pictureBox91 = new System.Windows.Forms.PictureBox();
            this.pictureBox92 = new System.Windows.Forms.PictureBox();
            this.pictureBox93 = new System.Windows.Forms.PictureBox();
            this.pictureBox94 = new System.Windows.Forms.PictureBox();
            this.pictureBox95 = new System.Windows.Forms.PictureBox();
            this.pictureBox86 = new System.Windows.Forms.PictureBox();
            this.pictureBox87 = new System.Windows.Forms.PictureBox();
            this.pictureBox88 = new System.Windows.Forms.PictureBox();
            this.pictureBox89 = new System.Windows.Forms.PictureBox();
            this.pictureBox90 = new System.Windows.Forms.PictureBox();
            this.pictureBox81 = new System.Windows.Forms.PictureBox();
            this.pictureBox82 = new System.Windows.Forms.PictureBox();
            this.pictureBox83 = new System.Windows.Forms.PictureBox();
            this.pictureBox84 = new System.Windows.Forms.PictureBox();
            this.pictureBox85 = new System.Windows.Forms.PictureBox();
            this.pictureBox76 = new System.Windows.Forms.PictureBox();
            this.pictureBox77 = new System.Windows.Forms.PictureBox();
            this.pictureBox78 = new System.Windows.Forms.PictureBox();
            this.pictureBox79 = new System.Windows.Forms.PictureBox();
            this.pictureBox80 = new System.Windows.Forms.PictureBox();
            this.BackButton = new System.Windows.Forms.Button();
            this.BuySellButton = new System.Windows.Forms.Button();
            this.label = new System.Windows.Forms.Label();
            this.GoldCountLabel = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox24)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox25)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox22)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox23)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox20)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox21)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox18)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox19)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox16)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox17)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox14)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox15)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox12)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox13)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox10)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox11)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox8)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox9)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox6)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox7)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox5)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.ShopAnimation)).BeginInit();
            this.tabControl1.SuspendLayout();
            this.ShopItems.SuspendLayout();
            this.WeaponsSell.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox46)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox47)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox48)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox49)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox50)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox41)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox42)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox43)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox44)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox45)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox36)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox37)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox38)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox39)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox40)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox31)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox32)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox33)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox34)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox35)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox26)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox27)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox28)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox29)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox30)).BeginInit();
            this.ArmorSell.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox71)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox72)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox73)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox74)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox75)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox66)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox67)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox68)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox69)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox70)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox61)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox62)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox63)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox64)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox65)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox56)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox57)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox58)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox59)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox60)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox51)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox52)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox53)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox54)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox55)).BeginInit();
            this.AccessorySell.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox96)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox97)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox98)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox99)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox100)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox91)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox92)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox93)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox94)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox95)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox86)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox87)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox88)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox89)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox90)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox81)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox82)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox83)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox84)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox85)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox76)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox77)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox78)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox79)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox80)).BeginInit();
            this.SuspendLayout();
            // 
            // pictureBox24
            // 
            this.pictureBox24.BackColor = System.Drawing.Color.DimGray;
            this.pictureBox24.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.pictureBox24.Cursor = System.Windows.Forms.Cursors.Hand;
            this.pictureBox24.Enabled = false;
            this.pictureBox24.Location = new System.Drawing.Point(408, 542);
            this.pictureBox24.Name = "pictureBox24";
            this.pictureBox24.Size = new System.Drawing.Size(128, 128);
            this.pictureBox24.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox24.TabIndex = 61;
            this.pictureBox24.TabStop = false;
            this.pictureBox24.Click += new System.EventHandler(this.ShopItemClick);
            // 
            // pictureBox25
            // 
            this.pictureBox25.BackColor = System.Drawing.Color.DimGray;
            this.pictureBox25.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.pictureBox25.Cursor = System.Windows.Forms.Cursors.Hand;
            this.pictureBox25.Enabled = false;
            this.pictureBox25.Location = new System.Drawing.Point(542, 542);
            this.pictureBox25.Name = "pictureBox25";
            this.pictureBox25.Size = new System.Drawing.Size(128, 128);
            this.pictureBox25.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox25.TabIndex = 60;
            this.pictureBox25.TabStop = false;
            this.pictureBox25.Click += new System.EventHandler(this.ShopItemClick);
            // 
            // pictureBox22
            // 
            this.pictureBox22.BackColor = System.Drawing.Color.DimGray;
            this.pictureBox22.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.pictureBox22.Cursor = System.Windows.Forms.Cursors.Hand;
            this.pictureBox22.Enabled = false;
            this.pictureBox22.Location = new System.Drawing.Point(140, 542);
            this.pictureBox22.Name = "pictureBox22";
            this.pictureBox22.Size = new System.Drawing.Size(128, 128);
            this.pictureBox22.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox22.TabIndex = 59;
            this.pictureBox22.TabStop = false;
            this.pictureBox22.Click += new System.EventHandler(this.ShopItemClick);
            // 
            // pictureBox23
            // 
            this.pictureBox23.BackColor = System.Drawing.Color.DimGray;
            this.pictureBox23.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.pictureBox23.Cursor = System.Windows.Forms.Cursors.Hand;
            this.pictureBox23.Enabled = false;
            this.pictureBox23.Location = new System.Drawing.Point(274, 542);
            this.pictureBox23.Name = "pictureBox23";
            this.pictureBox23.Size = new System.Drawing.Size(128, 128);
            this.pictureBox23.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox23.TabIndex = 58;
            this.pictureBox23.TabStop = false;
            this.pictureBox23.Click += new System.EventHandler(this.ShopItemClick);
            // 
            // pictureBox20
            // 
            this.pictureBox20.BackColor = System.Drawing.Color.DimGray;
            this.pictureBox20.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.pictureBox20.Cursor = System.Windows.Forms.Cursors.Hand;
            this.pictureBox20.Enabled = false;
            this.pictureBox20.Location = new System.Drawing.Point(542, 408);
            this.pictureBox20.Name = "pictureBox20";
            this.pictureBox20.Size = new System.Drawing.Size(128, 128);
            this.pictureBox20.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox20.TabIndex = 57;
            this.pictureBox20.TabStop = false;
            this.pictureBox20.Click += new System.EventHandler(this.ShopItemClick);
            // 
            // pictureBox21
            // 
            this.pictureBox21.BackColor = System.Drawing.Color.DimGray;
            this.pictureBox21.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.pictureBox21.Cursor = System.Windows.Forms.Cursors.Hand;
            this.pictureBox21.Enabled = false;
            this.pictureBox21.Location = new System.Drawing.Point(6, 542);
            this.pictureBox21.Name = "pictureBox21";
            this.pictureBox21.Size = new System.Drawing.Size(128, 128);
            this.pictureBox21.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox21.TabIndex = 56;
            this.pictureBox21.TabStop = false;
            this.pictureBox21.Click += new System.EventHandler(this.ShopItemClick);
            // 
            // pictureBox18
            // 
            this.pictureBox18.BackColor = System.Drawing.Color.DimGray;
            this.pictureBox18.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.pictureBox18.Cursor = System.Windows.Forms.Cursors.Hand;
            this.pictureBox18.Enabled = false;
            this.pictureBox18.Location = new System.Drawing.Point(274, 408);
            this.pictureBox18.Name = "pictureBox18";
            this.pictureBox18.Size = new System.Drawing.Size(128, 128);
            this.pictureBox18.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox18.TabIndex = 55;
            this.pictureBox18.TabStop = false;
            this.pictureBox18.Click += new System.EventHandler(this.ShopItemClick);
            // 
            // pictureBox19
            // 
            this.pictureBox19.BackColor = System.Drawing.Color.DimGray;
            this.pictureBox19.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.pictureBox19.Cursor = System.Windows.Forms.Cursors.Hand;
            this.pictureBox19.Enabled = false;
            this.pictureBox19.Location = new System.Drawing.Point(408, 408);
            this.pictureBox19.Name = "pictureBox19";
            this.pictureBox19.Size = new System.Drawing.Size(128, 128);
            this.pictureBox19.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox19.TabIndex = 54;
            this.pictureBox19.TabStop = false;
            this.pictureBox19.Click += new System.EventHandler(this.ShopItemClick);
            // 
            // pictureBox16
            // 
            this.pictureBox16.BackColor = System.Drawing.Color.DimGray;
            this.pictureBox16.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.pictureBox16.Cursor = System.Windows.Forms.Cursors.Hand;
            this.pictureBox16.Enabled = false;
            this.pictureBox16.Location = new System.Drawing.Point(6, 408);
            this.pictureBox16.Name = "pictureBox16";
            this.pictureBox16.Size = new System.Drawing.Size(128, 128);
            this.pictureBox16.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox16.TabIndex = 53;
            this.pictureBox16.TabStop = false;
            this.pictureBox16.Click += new System.EventHandler(this.ShopItemClick);
            // 
            // pictureBox17
            // 
            this.pictureBox17.BackColor = System.Drawing.Color.DimGray;
            this.pictureBox17.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.pictureBox17.Cursor = System.Windows.Forms.Cursors.Hand;
            this.pictureBox17.Enabled = false;
            this.pictureBox17.Location = new System.Drawing.Point(140, 408);
            this.pictureBox17.Name = "pictureBox17";
            this.pictureBox17.Size = new System.Drawing.Size(128, 128);
            this.pictureBox17.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox17.TabIndex = 52;
            this.pictureBox17.TabStop = false;
            this.pictureBox17.Click += new System.EventHandler(this.ShopItemClick);
            // 
            // pictureBox14
            // 
            this.pictureBox14.BackColor = System.Drawing.Color.DimGray;
            this.pictureBox14.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.pictureBox14.Cursor = System.Windows.Forms.Cursors.Hand;
            this.pictureBox14.Enabled = false;
            this.pictureBox14.Location = new System.Drawing.Point(408, 274);
            this.pictureBox14.Name = "pictureBox14";
            this.pictureBox14.Size = new System.Drawing.Size(128, 128);
            this.pictureBox14.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox14.TabIndex = 51;
            this.pictureBox14.TabStop = false;
            this.pictureBox14.Click += new System.EventHandler(this.ShopItemClick);
            // 
            // pictureBox15
            // 
            this.pictureBox15.BackColor = System.Drawing.Color.DimGray;
            this.pictureBox15.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.pictureBox15.Cursor = System.Windows.Forms.Cursors.Hand;
            this.pictureBox15.Enabled = false;
            this.pictureBox15.Location = new System.Drawing.Point(542, 274);
            this.pictureBox15.Name = "pictureBox15";
            this.pictureBox15.Size = new System.Drawing.Size(128, 128);
            this.pictureBox15.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox15.TabIndex = 50;
            this.pictureBox15.TabStop = false;
            this.pictureBox15.Click += new System.EventHandler(this.ShopItemClick);
            // 
            // pictureBox12
            // 
            this.pictureBox12.BackColor = System.Drawing.Color.DimGray;
            this.pictureBox12.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.pictureBox12.Cursor = System.Windows.Forms.Cursors.Hand;
            this.pictureBox12.Enabled = false;
            this.pictureBox12.Location = new System.Drawing.Point(140, 274);
            this.pictureBox12.Name = "pictureBox12";
            this.pictureBox12.Size = new System.Drawing.Size(128, 128);
            this.pictureBox12.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox12.TabIndex = 49;
            this.pictureBox12.TabStop = false;
            this.pictureBox12.Click += new System.EventHandler(this.ShopItemClick);
            // 
            // pictureBox13
            // 
            this.pictureBox13.BackColor = System.Drawing.Color.DimGray;
            this.pictureBox13.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.pictureBox13.Cursor = System.Windows.Forms.Cursors.Hand;
            this.pictureBox13.Enabled = false;
            this.pictureBox13.Location = new System.Drawing.Point(274, 274);
            this.pictureBox13.Name = "pictureBox13";
            this.pictureBox13.Size = new System.Drawing.Size(128, 128);
            this.pictureBox13.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox13.TabIndex = 48;
            this.pictureBox13.TabStop = false;
            this.pictureBox13.Click += new System.EventHandler(this.ShopItemClick);
            // 
            // pictureBox10
            // 
            this.pictureBox10.BackColor = System.Drawing.Color.DimGray;
            this.pictureBox10.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.pictureBox10.Cursor = System.Windows.Forms.Cursors.Hand;
            this.pictureBox10.Enabled = false;
            this.pictureBox10.Location = new System.Drawing.Point(542, 140);
            this.pictureBox10.Name = "pictureBox10";
            this.pictureBox10.Size = new System.Drawing.Size(128, 128);
            this.pictureBox10.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox10.TabIndex = 47;
            this.pictureBox10.TabStop = false;
            this.pictureBox10.Click += new System.EventHandler(this.ShopItemClick);
            // 
            // pictureBox11
            // 
            this.pictureBox11.BackColor = System.Drawing.Color.DimGray;
            this.pictureBox11.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.pictureBox11.Cursor = System.Windows.Forms.Cursors.Hand;
            this.pictureBox11.Enabled = false;
            this.pictureBox11.Location = new System.Drawing.Point(6, 274);
            this.pictureBox11.Name = "pictureBox11";
            this.pictureBox11.Size = new System.Drawing.Size(128, 128);
            this.pictureBox11.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox11.TabIndex = 46;
            this.pictureBox11.TabStop = false;
            this.pictureBox11.Click += new System.EventHandler(this.ShopItemClick);
            // 
            // pictureBox8
            // 
            this.pictureBox8.BackColor = System.Drawing.Color.DimGray;
            this.pictureBox8.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.pictureBox8.Cursor = System.Windows.Forms.Cursors.Hand;
            this.pictureBox8.Enabled = false;
            this.pictureBox8.Location = new System.Drawing.Point(274, 140);
            this.pictureBox8.Name = "pictureBox8";
            this.pictureBox8.Size = new System.Drawing.Size(128, 128);
            this.pictureBox8.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox8.TabIndex = 45;
            this.pictureBox8.TabStop = false;
            this.pictureBox8.Click += new System.EventHandler(this.ShopItemClick);
            // 
            // pictureBox9
            // 
            this.pictureBox9.BackColor = System.Drawing.Color.DimGray;
            this.pictureBox9.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.pictureBox9.Cursor = System.Windows.Forms.Cursors.Hand;
            this.pictureBox9.Enabled = false;
            this.pictureBox9.Location = new System.Drawing.Point(408, 140);
            this.pictureBox9.Name = "pictureBox9";
            this.pictureBox9.Size = new System.Drawing.Size(128, 128);
            this.pictureBox9.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox9.TabIndex = 44;
            this.pictureBox9.TabStop = false;
            this.pictureBox9.Click += new System.EventHandler(this.ShopItemClick);
            // 
            // pictureBox6
            // 
            this.pictureBox6.BackColor = System.Drawing.Color.DimGray;
            this.pictureBox6.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.pictureBox6.Cursor = System.Windows.Forms.Cursors.Hand;
            this.pictureBox6.Enabled = false;
            this.pictureBox6.Location = new System.Drawing.Point(6, 140);
            this.pictureBox6.Name = "pictureBox6";
            this.pictureBox6.Size = new System.Drawing.Size(128, 128);
            this.pictureBox6.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox6.TabIndex = 43;
            this.pictureBox6.TabStop = false;
            this.pictureBox6.Click += new System.EventHandler(this.ShopItemClick);
            // 
            // pictureBox7
            // 
            this.pictureBox7.BackColor = System.Drawing.Color.DimGray;
            this.pictureBox7.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.pictureBox7.Cursor = System.Windows.Forms.Cursors.Hand;
            this.pictureBox7.Enabled = false;
            this.pictureBox7.Location = new System.Drawing.Point(140, 140);
            this.pictureBox7.Name = "pictureBox7";
            this.pictureBox7.Size = new System.Drawing.Size(128, 128);
            this.pictureBox7.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox7.TabIndex = 42;
            this.pictureBox7.TabStop = false;
            this.pictureBox7.Click += new System.EventHandler(this.ShopItemClick);
            // 
            // pictureBox5
            // 
            this.pictureBox5.BackColor = System.Drawing.Color.DimGray;
            this.pictureBox5.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.pictureBox5.Cursor = System.Windows.Forms.Cursors.Hand;
            this.pictureBox5.Enabled = false;
            this.pictureBox5.Location = new System.Drawing.Point(542, 6);
            this.pictureBox5.Name = "pictureBox5";
            this.pictureBox5.Size = new System.Drawing.Size(128, 128);
            this.pictureBox5.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox5.TabIndex = 41;
            this.pictureBox5.TabStop = false;
            this.pictureBox5.Click += new System.EventHandler(this.ShopItemClick);
            // 
            // pictureBox4
            // 
            this.pictureBox4.BackColor = System.Drawing.Color.DimGray;
            this.pictureBox4.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.pictureBox4.Cursor = System.Windows.Forms.Cursors.Hand;
            this.pictureBox4.Enabled = false;
            this.pictureBox4.Location = new System.Drawing.Point(408, 6);
            this.pictureBox4.Name = "pictureBox4";
            this.pictureBox4.Size = new System.Drawing.Size(128, 128);
            this.pictureBox4.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox4.TabIndex = 40;
            this.pictureBox4.TabStop = false;
            this.pictureBox4.Click += new System.EventHandler(this.ShopItemClick);
            // 
            // pictureBox3
            // 
            this.pictureBox3.BackColor = System.Drawing.Color.DimGray;
            this.pictureBox3.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.pictureBox3.Cursor = System.Windows.Forms.Cursors.Hand;
            this.pictureBox3.Enabled = false;
            this.pictureBox3.Location = new System.Drawing.Point(274, 6);
            this.pictureBox3.Name = "pictureBox3";
            this.pictureBox3.Size = new System.Drawing.Size(128, 128);
            this.pictureBox3.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox3.TabIndex = 39;
            this.pictureBox3.TabStop = false;
            this.pictureBox3.Click += new System.EventHandler(this.ShopItemClick);
            // 
            // pictureBox2
            // 
            this.pictureBox2.BackColor = System.Drawing.Color.DimGray;
            this.pictureBox2.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.pictureBox2.Cursor = System.Windows.Forms.Cursors.Hand;
            this.pictureBox2.Enabled = false;
            this.pictureBox2.Location = new System.Drawing.Point(140, 6);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(128, 128);
            this.pictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox2.TabIndex = 38;
            this.pictureBox2.TabStop = false;
            this.pictureBox2.Click += new System.EventHandler(this.ShopItemClick);
            // 
            // pictureBox1
            // 
            this.pictureBox1.BackColor = System.Drawing.Color.DimGray;
            this.pictureBox1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.pictureBox1.Cursor = System.Windows.Forms.Cursors.Hand;
            this.pictureBox1.Enabled = false;
            this.pictureBox1.Location = new System.Drawing.Point(6, 6);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(128, 128);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox1.TabIndex = 37;
            this.pictureBox1.TabStop = false;
            this.pictureBox1.Click += new System.EventHandler(this.ShopItemClick);
            // 
            // ShopAnimation
            // 
            this.ShopAnimation.BackColor = System.Drawing.Color.Transparent;
            this.ShopAnimation.Cursor = System.Windows.Forms.Cursors.Arrow;
            this.ShopAnimation.Image = ((System.Drawing.Image)(resources.GetObject("ShopAnimation.Image")));
            this.ShopAnimation.Location = new System.Drawing.Point(1148, 47);
            this.ShopAnimation.Name = "ShopAnimation";
            this.ShopAnimation.Size = new System.Drawing.Size(213, 322);
            this.ShopAnimation.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.ShopAnimation.TabIndex = 62;
            this.ShopAnimation.TabStop = false;
            // 
            // ShopKeeperConversation
            // 
            this.ShopKeeperConversation.BackColor = System.Drawing.Color.Black;
            this.ShopKeeperConversation.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ShopKeeperConversation.ForeColor = System.Drawing.Color.Red;
            this.ShopKeeperConversation.Location = new System.Drawing.Point(1093, 394);
            this.ShopKeeperConversation.Name = "ShopKeeperConversation";
            this.ShopKeeperConversation.ReadOnly = true;
            this.ShopKeeperConversation.Size = new System.Drawing.Size(331, 358);
            this.ShopKeeperConversation.TabIndex = 64;
            this.ShopKeeperConversation.TabStop = false;
            this.ShopKeeperConversation.Text = "ShopKeeper\'s Conversation";
            this.ShopKeeperConversation.Click += new System.EventHandler(this.ShopKeeperConversation_Click);
            this.ShopKeeperConversation.DoubleClick += new System.EventHandler(this.ShopKeeperConversation_Click);
            // 
            // ItemDescription
            // 
            this.ItemDescription.BackColor = System.Drawing.Color.Black;
            this.ItemDescription.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ItemDescription.ForeColor = System.Drawing.Color.Red;
            this.ItemDescription.Location = new System.Drawing.Point(23, 263);
            this.ItemDescription.Name = "ItemDescription";
            this.ItemDescription.ReadOnly = true;
            this.ItemDescription.Size = new System.Drawing.Size(339, 489);
            this.ItemDescription.TabIndex = 65;
            this.ItemDescription.TabStop = false;
            this.ItemDescription.Text = "Item\'s Stats";
            this.ItemDescription.Click += new System.EventHandler(this.ItemDescription_Click);
            this.ItemDescription.DoubleClick += new System.EventHandler(this.ItemDescription_Click);
            // 
            // tabControl1
            // 
            this.tabControl1.Controls.Add(this.ShopItems);
            this.tabControl1.Controls.Add(this.WeaponsSell);
            this.tabControl1.Controls.Add(this.ArmorSell);
            this.tabControl1.Controls.Add(this.AccessorySell);
            this.tabControl1.Location = new System.Drawing.Point(382, 47);
            this.tabControl1.Name = "tabControl1";
            this.tabControl1.SelectedIndex = 0;
            this.tabControl1.Size = new System.Drawing.Size(685, 705);
            this.tabControl1.TabIndex = 66;
            this.tabControl1.TabStop = false;
            // 
            // ShopItems
            // 
            this.ShopItems.BackColor = System.Drawing.Color.Black;
            this.ShopItems.Controls.Add(this.pictureBox1);
            this.ShopItems.Controls.Add(this.pictureBox2);
            this.ShopItems.Controls.Add(this.pictureBox3);
            this.ShopItems.Controls.Add(this.pictureBox4);
            this.ShopItems.Controls.Add(this.pictureBox24);
            this.ShopItems.Controls.Add(this.pictureBox5);
            this.ShopItems.Controls.Add(this.pictureBox25);
            this.ShopItems.Controls.Add(this.pictureBox7);
            this.ShopItems.Controls.Add(this.pictureBox22);
            this.ShopItems.Controls.Add(this.pictureBox6);
            this.ShopItems.Controls.Add(this.pictureBox23);
            this.ShopItems.Controls.Add(this.pictureBox9);
            this.ShopItems.Controls.Add(this.pictureBox20);
            this.ShopItems.Controls.Add(this.pictureBox8);
            this.ShopItems.Controls.Add(this.pictureBox21);
            this.ShopItems.Controls.Add(this.pictureBox11);
            this.ShopItems.Controls.Add(this.pictureBox18);
            this.ShopItems.Controls.Add(this.pictureBox10);
            this.ShopItems.Controls.Add(this.pictureBox19);
            this.ShopItems.Controls.Add(this.pictureBox13);
            this.ShopItems.Controls.Add(this.pictureBox16);
            this.ShopItems.Controls.Add(this.pictureBox12);
            this.ShopItems.Controls.Add(this.pictureBox17);
            this.ShopItems.Controls.Add(this.pictureBox15);
            this.ShopItems.Controls.Add(this.pictureBox14);
            this.ShopItems.Location = new System.Drawing.Point(4, 25);
            this.ShopItems.Name = "ShopItems";
            this.ShopItems.Padding = new System.Windows.Forms.Padding(3);
            this.ShopItems.Size = new System.Drawing.Size(677, 676);
            this.ShopItems.TabIndex = 0;
            this.ShopItems.Text = "Shop";
            // 
            // WeaponsSell
            // 
            this.WeaponsSell.BackColor = System.Drawing.Color.Black;
            this.WeaponsSell.Controls.Add(this.pictureBox46);
            this.WeaponsSell.Controls.Add(this.pictureBox47);
            this.WeaponsSell.Controls.Add(this.pictureBox48);
            this.WeaponsSell.Controls.Add(this.pictureBox49);
            this.WeaponsSell.Controls.Add(this.pictureBox50);
            this.WeaponsSell.Controls.Add(this.pictureBox41);
            this.WeaponsSell.Controls.Add(this.pictureBox42);
            this.WeaponsSell.Controls.Add(this.pictureBox43);
            this.WeaponsSell.Controls.Add(this.pictureBox44);
            this.WeaponsSell.Controls.Add(this.pictureBox45);
            this.WeaponsSell.Controls.Add(this.pictureBox36);
            this.WeaponsSell.Controls.Add(this.pictureBox37);
            this.WeaponsSell.Controls.Add(this.pictureBox38);
            this.WeaponsSell.Controls.Add(this.pictureBox39);
            this.WeaponsSell.Controls.Add(this.pictureBox40);
            this.WeaponsSell.Controls.Add(this.pictureBox31);
            this.WeaponsSell.Controls.Add(this.pictureBox32);
            this.WeaponsSell.Controls.Add(this.pictureBox33);
            this.WeaponsSell.Controls.Add(this.pictureBox34);
            this.WeaponsSell.Controls.Add(this.pictureBox35);
            this.WeaponsSell.Controls.Add(this.pictureBox26);
            this.WeaponsSell.Controls.Add(this.pictureBox27);
            this.WeaponsSell.Controls.Add(this.pictureBox28);
            this.WeaponsSell.Controls.Add(this.pictureBox29);
            this.WeaponsSell.Controls.Add(this.pictureBox30);
            this.WeaponsSell.Location = new System.Drawing.Point(4, 25);
            this.WeaponsSell.Name = "WeaponsSell";
            this.WeaponsSell.Padding = new System.Windows.Forms.Padding(3);
            this.WeaponsSell.Size = new System.Drawing.Size(677, 676);
            this.WeaponsSell.TabIndex = 1;
            this.WeaponsSell.Text = "Sell Weapons";
            // 
            // pictureBox46
            // 
            this.pictureBox46.BackColor = System.Drawing.Color.DimGray;
            this.pictureBox46.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.pictureBox46.Cursor = System.Windows.Forms.Cursors.Hand;
            this.pictureBox46.Enabled = false;
            this.pictureBox46.Location = new System.Drawing.Point(6, 542);
            this.pictureBox46.Name = "pictureBox46";
            this.pictureBox46.Size = new System.Drawing.Size(128, 128);
            this.pictureBox46.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox46.TabIndex = 62;
            this.pictureBox46.TabStop = false;
            this.pictureBox46.Click += new System.EventHandler(this.WeaponSellClick);
            // 
            // pictureBox47
            // 
            this.pictureBox47.BackColor = System.Drawing.Color.DimGray;
            this.pictureBox47.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.pictureBox47.Cursor = System.Windows.Forms.Cursors.Hand;
            this.pictureBox47.Enabled = false;
            this.pictureBox47.Location = new System.Drawing.Point(140, 542);
            this.pictureBox47.Name = "pictureBox47";
            this.pictureBox47.Size = new System.Drawing.Size(128, 128);
            this.pictureBox47.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox47.TabIndex = 63;
            this.pictureBox47.TabStop = false;
            this.pictureBox47.Click += new System.EventHandler(this.WeaponSellClick);
            // 
            // pictureBox48
            // 
            this.pictureBox48.BackColor = System.Drawing.Color.DimGray;
            this.pictureBox48.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.pictureBox48.Cursor = System.Windows.Forms.Cursors.Hand;
            this.pictureBox48.Enabled = false;
            this.pictureBox48.Location = new System.Drawing.Point(274, 542);
            this.pictureBox48.Name = "pictureBox48";
            this.pictureBox48.Size = new System.Drawing.Size(128, 128);
            this.pictureBox48.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox48.TabIndex = 64;
            this.pictureBox48.TabStop = false;
            this.pictureBox48.Click += new System.EventHandler(this.WeaponSellClick);
            // 
            // pictureBox49
            // 
            this.pictureBox49.BackColor = System.Drawing.Color.DimGray;
            this.pictureBox49.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.pictureBox49.Cursor = System.Windows.Forms.Cursors.Hand;
            this.pictureBox49.Enabled = false;
            this.pictureBox49.Location = new System.Drawing.Point(408, 542);
            this.pictureBox49.Name = "pictureBox49";
            this.pictureBox49.Size = new System.Drawing.Size(128, 128);
            this.pictureBox49.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox49.TabIndex = 65;
            this.pictureBox49.TabStop = false;
            this.pictureBox49.Click += new System.EventHandler(this.WeaponSellClick);
            // 
            // pictureBox50
            // 
            this.pictureBox50.BackColor = System.Drawing.Color.DimGray;
            this.pictureBox50.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.pictureBox50.Cursor = System.Windows.Forms.Cursors.Hand;
            this.pictureBox50.Enabled = false;
            this.pictureBox50.Location = new System.Drawing.Point(542, 542);
            this.pictureBox50.Name = "pictureBox50";
            this.pictureBox50.Size = new System.Drawing.Size(128, 128);
            this.pictureBox50.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox50.TabIndex = 66;
            this.pictureBox50.TabStop = false;
            this.pictureBox50.Click += new System.EventHandler(this.WeaponSellClick);
            // 
            // pictureBox41
            // 
            this.pictureBox41.BackColor = System.Drawing.Color.DimGray;
            this.pictureBox41.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.pictureBox41.Cursor = System.Windows.Forms.Cursors.Hand;
            this.pictureBox41.Enabled = false;
            this.pictureBox41.Location = new System.Drawing.Point(6, 408);
            this.pictureBox41.Name = "pictureBox41";
            this.pictureBox41.Size = new System.Drawing.Size(128, 128);
            this.pictureBox41.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox41.TabIndex = 57;
            this.pictureBox41.TabStop = false;
            this.pictureBox41.Click += new System.EventHandler(this.WeaponSellClick);
            // 
            // pictureBox42
            // 
            this.pictureBox42.BackColor = System.Drawing.Color.DimGray;
            this.pictureBox42.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.pictureBox42.Cursor = System.Windows.Forms.Cursors.Hand;
            this.pictureBox42.Enabled = false;
            this.pictureBox42.Location = new System.Drawing.Point(140, 408);
            this.pictureBox42.Name = "pictureBox42";
            this.pictureBox42.Size = new System.Drawing.Size(128, 128);
            this.pictureBox42.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox42.TabIndex = 58;
            this.pictureBox42.TabStop = false;
            this.pictureBox42.Click += new System.EventHandler(this.WeaponSellClick);
            // 
            // pictureBox43
            // 
            this.pictureBox43.BackColor = System.Drawing.Color.DimGray;
            this.pictureBox43.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.pictureBox43.Cursor = System.Windows.Forms.Cursors.Hand;
            this.pictureBox43.Enabled = false;
            this.pictureBox43.Location = new System.Drawing.Point(274, 408);
            this.pictureBox43.Name = "pictureBox43";
            this.pictureBox43.Size = new System.Drawing.Size(128, 128);
            this.pictureBox43.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox43.TabIndex = 59;
            this.pictureBox43.TabStop = false;
            this.pictureBox43.Click += new System.EventHandler(this.WeaponSellClick);
            // 
            // pictureBox44
            // 
            this.pictureBox44.BackColor = System.Drawing.Color.DimGray;
            this.pictureBox44.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.pictureBox44.Cursor = System.Windows.Forms.Cursors.Hand;
            this.pictureBox44.Enabled = false;
            this.pictureBox44.Location = new System.Drawing.Point(408, 408);
            this.pictureBox44.Name = "pictureBox44";
            this.pictureBox44.Size = new System.Drawing.Size(128, 128);
            this.pictureBox44.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox44.TabIndex = 60;
            this.pictureBox44.TabStop = false;
            this.pictureBox44.Click += new System.EventHandler(this.WeaponSellClick);
            // 
            // pictureBox45
            // 
            this.pictureBox45.BackColor = System.Drawing.Color.DimGray;
            this.pictureBox45.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.pictureBox45.Cursor = System.Windows.Forms.Cursors.Hand;
            this.pictureBox45.Enabled = false;
            this.pictureBox45.Location = new System.Drawing.Point(542, 408);
            this.pictureBox45.Name = "pictureBox45";
            this.pictureBox45.Size = new System.Drawing.Size(128, 128);
            this.pictureBox45.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox45.TabIndex = 61;
            this.pictureBox45.TabStop = false;
            this.pictureBox45.Click += new System.EventHandler(this.WeaponSellClick);
            // 
            // pictureBox36
            // 
            this.pictureBox36.BackColor = System.Drawing.Color.DimGray;
            this.pictureBox36.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.pictureBox36.Cursor = System.Windows.Forms.Cursors.Hand;
            this.pictureBox36.Enabled = false;
            this.pictureBox36.Location = new System.Drawing.Point(6, 274);
            this.pictureBox36.Name = "pictureBox36";
            this.pictureBox36.Size = new System.Drawing.Size(128, 128);
            this.pictureBox36.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox36.TabIndex = 52;
            this.pictureBox36.TabStop = false;
            this.pictureBox36.Click += new System.EventHandler(this.WeaponSellClick);
            // 
            // pictureBox37
            // 
            this.pictureBox37.BackColor = System.Drawing.Color.DimGray;
            this.pictureBox37.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.pictureBox37.Cursor = System.Windows.Forms.Cursors.Hand;
            this.pictureBox37.Enabled = false;
            this.pictureBox37.Location = new System.Drawing.Point(140, 274);
            this.pictureBox37.Name = "pictureBox37";
            this.pictureBox37.Size = new System.Drawing.Size(128, 128);
            this.pictureBox37.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox37.TabIndex = 53;
            this.pictureBox37.TabStop = false;
            this.pictureBox37.Click += new System.EventHandler(this.WeaponSellClick);
            // 
            // pictureBox38
            // 
            this.pictureBox38.BackColor = System.Drawing.Color.DimGray;
            this.pictureBox38.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.pictureBox38.Cursor = System.Windows.Forms.Cursors.Hand;
            this.pictureBox38.Enabled = false;
            this.pictureBox38.Location = new System.Drawing.Point(274, 274);
            this.pictureBox38.Name = "pictureBox38";
            this.pictureBox38.Size = new System.Drawing.Size(128, 128);
            this.pictureBox38.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox38.TabIndex = 54;
            this.pictureBox38.TabStop = false;
            this.pictureBox38.Click += new System.EventHandler(this.WeaponSellClick);
            // 
            // pictureBox39
            // 
            this.pictureBox39.BackColor = System.Drawing.Color.DimGray;
            this.pictureBox39.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.pictureBox39.Cursor = System.Windows.Forms.Cursors.Hand;
            this.pictureBox39.Enabled = false;
            this.pictureBox39.Location = new System.Drawing.Point(408, 274);
            this.pictureBox39.Name = "pictureBox39";
            this.pictureBox39.Size = new System.Drawing.Size(128, 128);
            this.pictureBox39.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox39.TabIndex = 55;
            this.pictureBox39.TabStop = false;
            this.pictureBox39.Click += new System.EventHandler(this.WeaponSellClick);
            // 
            // pictureBox40
            // 
            this.pictureBox40.BackColor = System.Drawing.Color.DimGray;
            this.pictureBox40.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.pictureBox40.Cursor = System.Windows.Forms.Cursors.Hand;
            this.pictureBox40.Enabled = false;
            this.pictureBox40.Location = new System.Drawing.Point(542, 274);
            this.pictureBox40.Name = "pictureBox40";
            this.pictureBox40.Size = new System.Drawing.Size(128, 128);
            this.pictureBox40.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox40.TabIndex = 56;
            this.pictureBox40.TabStop = false;
            this.pictureBox40.Click += new System.EventHandler(this.WeaponSellClick);
            // 
            // pictureBox31
            // 
            this.pictureBox31.BackColor = System.Drawing.Color.DimGray;
            this.pictureBox31.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.pictureBox31.Cursor = System.Windows.Forms.Cursors.Hand;
            this.pictureBox31.Enabled = false;
            this.pictureBox31.Location = new System.Drawing.Point(6, 140);
            this.pictureBox31.Name = "pictureBox31";
            this.pictureBox31.Size = new System.Drawing.Size(128, 128);
            this.pictureBox31.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox31.TabIndex = 47;
            this.pictureBox31.TabStop = false;
            this.pictureBox31.Click += new System.EventHandler(this.WeaponSellClick);
            // 
            // pictureBox32
            // 
            this.pictureBox32.BackColor = System.Drawing.Color.DimGray;
            this.pictureBox32.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.pictureBox32.Cursor = System.Windows.Forms.Cursors.Hand;
            this.pictureBox32.Enabled = false;
            this.pictureBox32.Location = new System.Drawing.Point(140, 140);
            this.pictureBox32.Name = "pictureBox32";
            this.pictureBox32.Size = new System.Drawing.Size(128, 128);
            this.pictureBox32.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox32.TabIndex = 48;
            this.pictureBox32.TabStop = false;
            this.pictureBox32.Click += new System.EventHandler(this.WeaponSellClick);
            // 
            // pictureBox33
            // 
            this.pictureBox33.BackColor = System.Drawing.Color.DimGray;
            this.pictureBox33.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.pictureBox33.Cursor = System.Windows.Forms.Cursors.Hand;
            this.pictureBox33.Enabled = false;
            this.pictureBox33.Location = new System.Drawing.Point(274, 140);
            this.pictureBox33.Name = "pictureBox33";
            this.pictureBox33.Size = new System.Drawing.Size(128, 128);
            this.pictureBox33.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox33.TabIndex = 49;
            this.pictureBox33.TabStop = false;
            this.pictureBox33.Click += new System.EventHandler(this.WeaponSellClick);
            // 
            // pictureBox34
            // 
            this.pictureBox34.BackColor = System.Drawing.Color.DimGray;
            this.pictureBox34.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.pictureBox34.Cursor = System.Windows.Forms.Cursors.Hand;
            this.pictureBox34.Enabled = false;
            this.pictureBox34.Location = new System.Drawing.Point(408, 140);
            this.pictureBox34.Name = "pictureBox34";
            this.pictureBox34.Size = new System.Drawing.Size(128, 128);
            this.pictureBox34.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox34.TabIndex = 50;
            this.pictureBox34.TabStop = false;
            this.pictureBox34.Click += new System.EventHandler(this.WeaponSellClick);
            // 
            // pictureBox35
            // 
            this.pictureBox35.BackColor = System.Drawing.Color.DimGray;
            this.pictureBox35.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.pictureBox35.Cursor = System.Windows.Forms.Cursors.Hand;
            this.pictureBox35.Enabled = false;
            this.pictureBox35.Location = new System.Drawing.Point(542, 140);
            this.pictureBox35.Name = "pictureBox35";
            this.pictureBox35.Size = new System.Drawing.Size(128, 128);
            this.pictureBox35.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox35.TabIndex = 51;
            this.pictureBox35.TabStop = false;
            this.pictureBox35.Click += new System.EventHandler(this.WeaponSellClick);
            // 
            // pictureBox26
            // 
            this.pictureBox26.BackColor = System.Drawing.Color.DimGray;
            this.pictureBox26.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.pictureBox26.Cursor = System.Windows.Forms.Cursors.Hand;
            this.pictureBox26.Enabled = false;
            this.pictureBox26.Location = new System.Drawing.Point(6, 6);
            this.pictureBox26.Name = "pictureBox26";
            this.pictureBox26.Size = new System.Drawing.Size(128, 128);
            this.pictureBox26.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox26.TabIndex = 42;
            this.pictureBox26.TabStop = false;
            this.pictureBox26.Click += new System.EventHandler(this.WeaponSellClick);
            // 
            // pictureBox27
            // 
            this.pictureBox27.BackColor = System.Drawing.Color.DimGray;
            this.pictureBox27.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.pictureBox27.Cursor = System.Windows.Forms.Cursors.Hand;
            this.pictureBox27.Enabled = false;
            this.pictureBox27.Location = new System.Drawing.Point(140, 6);
            this.pictureBox27.Name = "pictureBox27";
            this.pictureBox27.Size = new System.Drawing.Size(128, 128);
            this.pictureBox27.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox27.TabIndex = 43;
            this.pictureBox27.TabStop = false;
            this.pictureBox27.Click += new System.EventHandler(this.WeaponSellClick);
            // 
            // pictureBox28
            // 
            this.pictureBox28.BackColor = System.Drawing.Color.DimGray;
            this.pictureBox28.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.pictureBox28.Cursor = System.Windows.Forms.Cursors.Hand;
            this.pictureBox28.Enabled = false;
            this.pictureBox28.Location = new System.Drawing.Point(274, 6);
            this.pictureBox28.Name = "pictureBox28";
            this.pictureBox28.Size = new System.Drawing.Size(128, 128);
            this.pictureBox28.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox28.TabIndex = 44;
            this.pictureBox28.TabStop = false;
            this.pictureBox28.Click += new System.EventHandler(this.WeaponSellClick);
            // 
            // pictureBox29
            // 
            this.pictureBox29.BackColor = System.Drawing.Color.DimGray;
            this.pictureBox29.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.pictureBox29.Cursor = System.Windows.Forms.Cursors.Hand;
            this.pictureBox29.Enabled = false;
            this.pictureBox29.Location = new System.Drawing.Point(408, 6);
            this.pictureBox29.Name = "pictureBox29";
            this.pictureBox29.Size = new System.Drawing.Size(128, 128);
            this.pictureBox29.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox29.TabIndex = 45;
            this.pictureBox29.TabStop = false;
            this.pictureBox29.Click += new System.EventHandler(this.WeaponSellClick);
            // 
            // pictureBox30
            // 
            this.pictureBox30.BackColor = System.Drawing.Color.DimGray;
            this.pictureBox30.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.pictureBox30.Cursor = System.Windows.Forms.Cursors.Hand;
            this.pictureBox30.Enabled = false;
            this.pictureBox30.Location = new System.Drawing.Point(542, 6);
            this.pictureBox30.Name = "pictureBox30";
            this.pictureBox30.Size = new System.Drawing.Size(128, 128);
            this.pictureBox30.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox30.TabIndex = 46;
            this.pictureBox30.TabStop = false;
            this.pictureBox30.Click += new System.EventHandler(this.WeaponSellClick);
            // 
            // ArmorSell
            // 
            this.ArmorSell.BackColor = System.Drawing.Color.Black;
            this.ArmorSell.Controls.Add(this.pictureBox71);
            this.ArmorSell.Controls.Add(this.pictureBox72);
            this.ArmorSell.Controls.Add(this.pictureBox73);
            this.ArmorSell.Controls.Add(this.pictureBox74);
            this.ArmorSell.Controls.Add(this.pictureBox75);
            this.ArmorSell.Controls.Add(this.pictureBox66);
            this.ArmorSell.Controls.Add(this.pictureBox67);
            this.ArmorSell.Controls.Add(this.pictureBox68);
            this.ArmorSell.Controls.Add(this.pictureBox69);
            this.ArmorSell.Controls.Add(this.pictureBox70);
            this.ArmorSell.Controls.Add(this.pictureBox61);
            this.ArmorSell.Controls.Add(this.pictureBox62);
            this.ArmorSell.Controls.Add(this.pictureBox63);
            this.ArmorSell.Controls.Add(this.pictureBox64);
            this.ArmorSell.Controls.Add(this.pictureBox65);
            this.ArmorSell.Controls.Add(this.pictureBox56);
            this.ArmorSell.Controls.Add(this.pictureBox57);
            this.ArmorSell.Controls.Add(this.pictureBox58);
            this.ArmorSell.Controls.Add(this.pictureBox59);
            this.ArmorSell.Controls.Add(this.pictureBox60);
            this.ArmorSell.Controls.Add(this.pictureBox51);
            this.ArmorSell.Controls.Add(this.pictureBox52);
            this.ArmorSell.Controls.Add(this.pictureBox53);
            this.ArmorSell.Controls.Add(this.pictureBox54);
            this.ArmorSell.Controls.Add(this.pictureBox55);
            this.ArmorSell.Location = new System.Drawing.Point(4, 25);
            this.ArmorSell.Name = "ArmorSell";
            this.ArmorSell.Padding = new System.Windows.Forms.Padding(3);
            this.ArmorSell.Size = new System.Drawing.Size(677, 676);
            this.ArmorSell.TabIndex = 2;
            this.ArmorSell.Text = "Sell Armor";
            // 
            // pictureBox71
            // 
            this.pictureBox71.BackColor = System.Drawing.Color.DimGray;
            this.pictureBox71.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.pictureBox71.Cursor = System.Windows.Forms.Cursors.Hand;
            this.pictureBox71.Enabled = false;
            this.pictureBox71.Location = new System.Drawing.Point(6, 542);
            this.pictureBox71.Name = "pictureBox71";
            this.pictureBox71.Size = new System.Drawing.Size(128, 128);
            this.pictureBox71.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox71.TabIndex = 67;
            this.pictureBox71.TabStop = false;
            this.pictureBox71.Click += new System.EventHandler(this.ArmorSellClick);
            // 
            // pictureBox72
            // 
            this.pictureBox72.BackColor = System.Drawing.Color.DimGray;
            this.pictureBox72.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.pictureBox72.Cursor = System.Windows.Forms.Cursors.Hand;
            this.pictureBox72.Enabled = false;
            this.pictureBox72.Location = new System.Drawing.Point(140, 542);
            this.pictureBox72.Name = "pictureBox72";
            this.pictureBox72.Size = new System.Drawing.Size(128, 128);
            this.pictureBox72.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox72.TabIndex = 68;
            this.pictureBox72.TabStop = false;
            this.pictureBox72.Click += new System.EventHandler(this.ArmorSellClick);
            // 
            // pictureBox73
            // 
            this.pictureBox73.BackColor = System.Drawing.Color.DimGray;
            this.pictureBox73.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.pictureBox73.Cursor = System.Windows.Forms.Cursors.Hand;
            this.pictureBox73.Enabled = false;
            this.pictureBox73.Location = new System.Drawing.Point(274, 542);
            this.pictureBox73.Name = "pictureBox73";
            this.pictureBox73.Size = new System.Drawing.Size(128, 128);
            this.pictureBox73.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox73.TabIndex = 69;
            this.pictureBox73.TabStop = false;
            this.pictureBox73.Click += new System.EventHandler(this.ArmorSellClick);
            // 
            // pictureBox74
            // 
            this.pictureBox74.BackColor = System.Drawing.Color.DimGray;
            this.pictureBox74.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.pictureBox74.Cursor = System.Windows.Forms.Cursors.Hand;
            this.pictureBox74.Enabled = false;
            this.pictureBox74.Location = new System.Drawing.Point(408, 542);
            this.pictureBox74.Name = "pictureBox74";
            this.pictureBox74.Size = new System.Drawing.Size(128, 128);
            this.pictureBox74.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox74.TabIndex = 70;
            this.pictureBox74.TabStop = false;
            this.pictureBox74.Click += new System.EventHandler(this.ArmorSellClick);
            // 
            // pictureBox75
            // 
            this.pictureBox75.BackColor = System.Drawing.Color.DimGray;
            this.pictureBox75.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.pictureBox75.Cursor = System.Windows.Forms.Cursors.Hand;
            this.pictureBox75.Enabled = false;
            this.pictureBox75.Location = new System.Drawing.Point(542, 542);
            this.pictureBox75.Name = "pictureBox75";
            this.pictureBox75.Size = new System.Drawing.Size(128, 128);
            this.pictureBox75.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox75.TabIndex = 71;
            this.pictureBox75.TabStop = false;
            this.pictureBox75.Click += new System.EventHandler(this.ArmorSellClick);
            // 
            // pictureBox66
            // 
            this.pictureBox66.BackColor = System.Drawing.Color.DimGray;
            this.pictureBox66.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.pictureBox66.Cursor = System.Windows.Forms.Cursors.Hand;
            this.pictureBox66.Enabled = false;
            this.pictureBox66.Location = new System.Drawing.Point(6, 408);
            this.pictureBox66.Name = "pictureBox66";
            this.pictureBox66.Size = new System.Drawing.Size(128, 128);
            this.pictureBox66.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox66.TabIndex = 62;
            this.pictureBox66.TabStop = false;
            this.pictureBox66.Click += new System.EventHandler(this.ArmorSellClick);
            // 
            // pictureBox67
            // 
            this.pictureBox67.BackColor = System.Drawing.Color.DimGray;
            this.pictureBox67.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.pictureBox67.Cursor = System.Windows.Forms.Cursors.Hand;
            this.pictureBox67.Enabled = false;
            this.pictureBox67.Location = new System.Drawing.Point(140, 408);
            this.pictureBox67.Name = "pictureBox67";
            this.pictureBox67.Size = new System.Drawing.Size(128, 128);
            this.pictureBox67.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox67.TabIndex = 63;
            this.pictureBox67.TabStop = false;
            this.pictureBox67.Click += new System.EventHandler(this.ArmorSellClick);
            // 
            // pictureBox68
            // 
            this.pictureBox68.BackColor = System.Drawing.Color.DimGray;
            this.pictureBox68.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.pictureBox68.Cursor = System.Windows.Forms.Cursors.Hand;
            this.pictureBox68.Enabled = false;
            this.pictureBox68.Location = new System.Drawing.Point(274, 408);
            this.pictureBox68.Name = "pictureBox68";
            this.pictureBox68.Size = new System.Drawing.Size(128, 128);
            this.pictureBox68.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox68.TabIndex = 64;
            this.pictureBox68.TabStop = false;
            this.pictureBox68.Click += new System.EventHandler(this.ArmorSellClick);
            // 
            // pictureBox69
            // 
            this.pictureBox69.BackColor = System.Drawing.Color.DimGray;
            this.pictureBox69.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.pictureBox69.Cursor = System.Windows.Forms.Cursors.Hand;
            this.pictureBox69.Enabled = false;
            this.pictureBox69.Location = new System.Drawing.Point(408, 408);
            this.pictureBox69.Name = "pictureBox69";
            this.pictureBox69.Size = new System.Drawing.Size(128, 128);
            this.pictureBox69.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox69.TabIndex = 65;
            this.pictureBox69.TabStop = false;
            this.pictureBox69.Click += new System.EventHandler(this.ArmorSellClick);
            // 
            // pictureBox70
            // 
            this.pictureBox70.BackColor = System.Drawing.Color.DimGray;
            this.pictureBox70.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.pictureBox70.Cursor = System.Windows.Forms.Cursors.Hand;
            this.pictureBox70.Enabled = false;
            this.pictureBox70.Location = new System.Drawing.Point(542, 408);
            this.pictureBox70.Name = "pictureBox70";
            this.pictureBox70.Size = new System.Drawing.Size(128, 128);
            this.pictureBox70.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox70.TabIndex = 66;
            this.pictureBox70.TabStop = false;
            this.pictureBox70.Click += new System.EventHandler(this.ArmorSellClick);
            // 
            // pictureBox61
            // 
            this.pictureBox61.BackColor = System.Drawing.Color.DimGray;
            this.pictureBox61.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.pictureBox61.Cursor = System.Windows.Forms.Cursors.Hand;
            this.pictureBox61.Enabled = false;
            this.pictureBox61.Location = new System.Drawing.Point(6, 274);
            this.pictureBox61.Name = "pictureBox61";
            this.pictureBox61.Size = new System.Drawing.Size(128, 128);
            this.pictureBox61.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox61.TabIndex = 57;
            this.pictureBox61.TabStop = false;
            this.pictureBox61.Click += new System.EventHandler(this.ArmorSellClick);
            // 
            // pictureBox62
            // 
            this.pictureBox62.BackColor = System.Drawing.Color.DimGray;
            this.pictureBox62.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.pictureBox62.Cursor = System.Windows.Forms.Cursors.Hand;
            this.pictureBox62.Enabled = false;
            this.pictureBox62.Location = new System.Drawing.Point(140, 274);
            this.pictureBox62.Name = "pictureBox62";
            this.pictureBox62.Size = new System.Drawing.Size(128, 128);
            this.pictureBox62.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox62.TabIndex = 58;
            this.pictureBox62.TabStop = false;
            this.pictureBox62.Click += new System.EventHandler(this.ArmorSellClick);
            // 
            // pictureBox63
            // 
            this.pictureBox63.BackColor = System.Drawing.Color.DimGray;
            this.pictureBox63.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.pictureBox63.Cursor = System.Windows.Forms.Cursors.Hand;
            this.pictureBox63.Enabled = false;
            this.pictureBox63.Location = new System.Drawing.Point(274, 274);
            this.pictureBox63.Name = "pictureBox63";
            this.pictureBox63.Size = new System.Drawing.Size(128, 128);
            this.pictureBox63.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox63.TabIndex = 59;
            this.pictureBox63.TabStop = false;
            this.pictureBox63.Click += new System.EventHandler(this.ArmorSellClick);
            // 
            // pictureBox64
            // 
            this.pictureBox64.BackColor = System.Drawing.Color.DimGray;
            this.pictureBox64.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.pictureBox64.Cursor = System.Windows.Forms.Cursors.Hand;
            this.pictureBox64.Enabled = false;
            this.pictureBox64.Location = new System.Drawing.Point(408, 274);
            this.pictureBox64.Name = "pictureBox64";
            this.pictureBox64.Size = new System.Drawing.Size(128, 128);
            this.pictureBox64.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox64.TabIndex = 60;
            this.pictureBox64.TabStop = false;
            this.pictureBox64.Click += new System.EventHandler(this.ArmorSellClick);
            // 
            // pictureBox65
            // 
            this.pictureBox65.BackColor = System.Drawing.Color.DimGray;
            this.pictureBox65.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.pictureBox65.Cursor = System.Windows.Forms.Cursors.Hand;
            this.pictureBox65.Enabled = false;
            this.pictureBox65.Location = new System.Drawing.Point(542, 274);
            this.pictureBox65.Name = "pictureBox65";
            this.pictureBox65.Size = new System.Drawing.Size(128, 128);
            this.pictureBox65.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox65.TabIndex = 61;
            this.pictureBox65.TabStop = false;
            this.pictureBox65.Click += new System.EventHandler(this.ArmorSellClick);
            // 
            // pictureBox56
            // 
            this.pictureBox56.BackColor = System.Drawing.Color.DimGray;
            this.pictureBox56.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.pictureBox56.Cursor = System.Windows.Forms.Cursors.Hand;
            this.pictureBox56.Enabled = false;
            this.pictureBox56.Location = new System.Drawing.Point(6, 140);
            this.pictureBox56.Name = "pictureBox56";
            this.pictureBox56.Size = new System.Drawing.Size(128, 128);
            this.pictureBox56.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox56.TabIndex = 52;
            this.pictureBox56.TabStop = false;
            this.pictureBox56.Click += new System.EventHandler(this.ArmorSellClick);
            // 
            // pictureBox57
            // 
            this.pictureBox57.BackColor = System.Drawing.Color.DimGray;
            this.pictureBox57.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.pictureBox57.Cursor = System.Windows.Forms.Cursors.Hand;
            this.pictureBox57.Enabled = false;
            this.pictureBox57.Location = new System.Drawing.Point(140, 140);
            this.pictureBox57.Name = "pictureBox57";
            this.pictureBox57.Size = new System.Drawing.Size(128, 128);
            this.pictureBox57.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox57.TabIndex = 53;
            this.pictureBox57.TabStop = false;
            this.pictureBox57.Click += new System.EventHandler(this.ArmorSellClick);
            // 
            // pictureBox58
            // 
            this.pictureBox58.BackColor = System.Drawing.Color.DimGray;
            this.pictureBox58.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.pictureBox58.Cursor = System.Windows.Forms.Cursors.Hand;
            this.pictureBox58.Enabled = false;
            this.pictureBox58.Location = new System.Drawing.Point(274, 140);
            this.pictureBox58.Name = "pictureBox58";
            this.pictureBox58.Size = new System.Drawing.Size(128, 128);
            this.pictureBox58.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox58.TabIndex = 54;
            this.pictureBox58.TabStop = false;
            this.pictureBox58.Click += new System.EventHandler(this.ArmorSellClick);
            // 
            // pictureBox59
            // 
            this.pictureBox59.BackColor = System.Drawing.Color.DimGray;
            this.pictureBox59.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.pictureBox59.Cursor = System.Windows.Forms.Cursors.Hand;
            this.pictureBox59.Enabled = false;
            this.pictureBox59.Location = new System.Drawing.Point(408, 140);
            this.pictureBox59.Name = "pictureBox59";
            this.pictureBox59.Size = new System.Drawing.Size(128, 128);
            this.pictureBox59.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox59.TabIndex = 55;
            this.pictureBox59.TabStop = false;
            this.pictureBox59.Click += new System.EventHandler(this.ArmorSellClick);
            // 
            // pictureBox60
            // 
            this.pictureBox60.BackColor = System.Drawing.Color.DimGray;
            this.pictureBox60.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.pictureBox60.Cursor = System.Windows.Forms.Cursors.Hand;
            this.pictureBox60.Enabled = false;
            this.pictureBox60.Location = new System.Drawing.Point(542, 140);
            this.pictureBox60.Name = "pictureBox60";
            this.pictureBox60.Size = new System.Drawing.Size(128, 128);
            this.pictureBox60.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox60.TabIndex = 56;
            this.pictureBox60.TabStop = false;
            this.pictureBox60.Click += new System.EventHandler(this.ArmorSellClick);
            // 
            // pictureBox51
            // 
            this.pictureBox51.BackColor = System.Drawing.Color.DimGray;
            this.pictureBox51.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.pictureBox51.Cursor = System.Windows.Forms.Cursors.Hand;
            this.pictureBox51.Enabled = false;
            this.pictureBox51.Location = new System.Drawing.Point(6, 6);
            this.pictureBox51.Name = "pictureBox51";
            this.pictureBox51.Size = new System.Drawing.Size(128, 128);
            this.pictureBox51.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox51.TabIndex = 47;
            this.pictureBox51.TabStop = false;
            this.pictureBox51.Click += new System.EventHandler(this.ArmorSellClick);
            // 
            // pictureBox52
            // 
            this.pictureBox52.BackColor = System.Drawing.Color.DimGray;
            this.pictureBox52.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.pictureBox52.Cursor = System.Windows.Forms.Cursors.Hand;
            this.pictureBox52.Enabled = false;
            this.pictureBox52.Location = new System.Drawing.Point(140, 6);
            this.pictureBox52.Name = "pictureBox52";
            this.pictureBox52.Size = new System.Drawing.Size(128, 128);
            this.pictureBox52.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox52.TabIndex = 48;
            this.pictureBox52.TabStop = false;
            this.pictureBox52.Click += new System.EventHandler(this.ArmorSellClick);
            // 
            // pictureBox53
            // 
            this.pictureBox53.BackColor = System.Drawing.Color.DimGray;
            this.pictureBox53.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.pictureBox53.Cursor = System.Windows.Forms.Cursors.Hand;
            this.pictureBox53.Enabled = false;
            this.pictureBox53.Location = new System.Drawing.Point(274, 6);
            this.pictureBox53.Name = "pictureBox53";
            this.pictureBox53.Size = new System.Drawing.Size(128, 128);
            this.pictureBox53.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox53.TabIndex = 49;
            this.pictureBox53.TabStop = false;
            this.pictureBox53.Click += new System.EventHandler(this.ArmorSellClick);
            // 
            // pictureBox54
            // 
            this.pictureBox54.BackColor = System.Drawing.Color.DimGray;
            this.pictureBox54.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.pictureBox54.Cursor = System.Windows.Forms.Cursors.Hand;
            this.pictureBox54.Enabled = false;
            this.pictureBox54.Location = new System.Drawing.Point(408, 6);
            this.pictureBox54.Name = "pictureBox54";
            this.pictureBox54.Size = new System.Drawing.Size(128, 128);
            this.pictureBox54.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox54.TabIndex = 50;
            this.pictureBox54.TabStop = false;
            this.pictureBox54.Click += new System.EventHandler(this.ArmorSellClick);
            // 
            // pictureBox55
            // 
            this.pictureBox55.BackColor = System.Drawing.Color.DimGray;
            this.pictureBox55.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.pictureBox55.Cursor = System.Windows.Forms.Cursors.Hand;
            this.pictureBox55.Enabled = false;
            this.pictureBox55.Location = new System.Drawing.Point(542, 6);
            this.pictureBox55.Name = "pictureBox55";
            this.pictureBox55.Size = new System.Drawing.Size(128, 128);
            this.pictureBox55.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox55.TabIndex = 51;
            this.pictureBox55.TabStop = false;
            this.pictureBox55.Click += new System.EventHandler(this.ArmorSellClick);
            // 
            // AccessorySell
            // 
            this.AccessorySell.BackColor = System.Drawing.Color.Black;
            this.AccessorySell.Controls.Add(this.pictureBox96);
            this.AccessorySell.Controls.Add(this.pictureBox97);
            this.AccessorySell.Controls.Add(this.pictureBox98);
            this.AccessorySell.Controls.Add(this.pictureBox99);
            this.AccessorySell.Controls.Add(this.pictureBox100);
            this.AccessorySell.Controls.Add(this.pictureBox91);
            this.AccessorySell.Controls.Add(this.pictureBox92);
            this.AccessorySell.Controls.Add(this.pictureBox93);
            this.AccessorySell.Controls.Add(this.pictureBox94);
            this.AccessorySell.Controls.Add(this.pictureBox95);
            this.AccessorySell.Controls.Add(this.pictureBox86);
            this.AccessorySell.Controls.Add(this.pictureBox87);
            this.AccessorySell.Controls.Add(this.pictureBox88);
            this.AccessorySell.Controls.Add(this.pictureBox89);
            this.AccessorySell.Controls.Add(this.pictureBox90);
            this.AccessorySell.Controls.Add(this.pictureBox81);
            this.AccessorySell.Controls.Add(this.pictureBox82);
            this.AccessorySell.Controls.Add(this.pictureBox83);
            this.AccessorySell.Controls.Add(this.pictureBox84);
            this.AccessorySell.Controls.Add(this.pictureBox85);
            this.AccessorySell.Controls.Add(this.pictureBox76);
            this.AccessorySell.Controls.Add(this.pictureBox77);
            this.AccessorySell.Controls.Add(this.pictureBox78);
            this.AccessorySell.Controls.Add(this.pictureBox79);
            this.AccessorySell.Controls.Add(this.pictureBox80);
            this.AccessorySell.Location = new System.Drawing.Point(4, 25);
            this.AccessorySell.Name = "AccessorySell";
            this.AccessorySell.Padding = new System.Windows.Forms.Padding(3);
            this.AccessorySell.Size = new System.Drawing.Size(677, 676);
            this.AccessorySell.TabIndex = 3;
            this.AccessorySell.Text = "Sell Accessories";
            // 
            // pictureBox96
            // 
            this.pictureBox96.BackColor = System.Drawing.Color.DimGray;
            this.pictureBox96.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.pictureBox96.Cursor = System.Windows.Forms.Cursors.Hand;
            this.pictureBox96.Enabled = false;
            this.pictureBox96.Location = new System.Drawing.Point(6, 542);
            this.pictureBox96.Name = "pictureBox96";
            this.pictureBox96.Size = new System.Drawing.Size(128, 128);
            this.pictureBox96.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox96.TabIndex = 67;
            this.pictureBox96.TabStop = false;
            this.pictureBox96.Click += new System.EventHandler(this.AccessorySellClick);
            // 
            // pictureBox97
            // 
            this.pictureBox97.BackColor = System.Drawing.Color.DimGray;
            this.pictureBox97.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.pictureBox97.Cursor = System.Windows.Forms.Cursors.Hand;
            this.pictureBox97.Enabled = false;
            this.pictureBox97.Location = new System.Drawing.Point(140, 542);
            this.pictureBox97.Name = "pictureBox97";
            this.pictureBox97.Size = new System.Drawing.Size(128, 128);
            this.pictureBox97.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox97.TabIndex = 68;
            this.pictureBox97.TabStop = false;
            this.pictureBox97.Click += new System.EventHandler(this.AccessorySellClick);
            // 
            // pictureBox98
            // 
            this.pictureBox98.BackColor = System.Drawing.Color.DimGray;
            this.pictureBox98.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.pictureBox98.Cursor = System.Windows.Forms.Cursors.Hand;
            this.pictureBox98.Enabled = false;
            this.pictureBox98.Location = new System.Drawing.Point(274, 542);
            this.pictureBox98.Name = "pictureBox98";
            this.pictureBox98.Size = new System.Drawing.Size(128, 128);
            this.pictureBox98.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox98.TabIndex = 69;
            this.pictureBox98.TabStop = false;
            this.pictureBox98.Click += new System.EventHandler(this.AccessorySellClick);
            // 
            // pictureBox99
            // 
            this.pictureBox99.BackColor = System.Drawing.Color.DimGray;
            this.pictureBox99.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.pictureBox99.Cursor = System.Windows.Forms.Cursors.Hand;
            this.pictureBox99.Enabled = false;
            this.pictureBox99.Location = new System.Drawing.Point(408, 542);
            this.pictureBox99.Name = "pictureBox99";
            this.pictureBox99.Size = new System.Drawing.Size(128, 128);
            this.pictureBox99.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox99.TabIndex = 70;
            this.pictureBox99.TabStop = false;
            this.pictureBox99.Click += new System.EventHandler(this.AccessorySellClick);
            // 
            // pictureBox100
            // 
            this.pictureBox100.BackColor = System.Drawing.Color.DimGray;
            this.pictureBox100.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.pictureBox100.Cursor = System.Windows.Forms.Cursors.Hand;
            this.pictureBox100.Enabled = false;
            this.pictureBox100.Location = new System.Drawing.Point(542, 542);
            this.pictureBox100.Name = "pictureBox100";
            this.pictureBox100.Size = new System.Drawing.Size(128, 128);
            this.pictureBox100.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox100.TabIndex = 71;
            this.pictureBox100.TabStop = false;
            this.pictureBox100.Click += new System.EventHandler(this.AccessorySellClick);
            // 
            // pictureBox91
            // 
            this.pictureBox91.BackColor = System.Drawing.Color.DimGray;
            this.pictureBox91.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.pictureBox91.Cursor = System.Windows.Forms.Cursors.Hand;
            this.pictureBox91.Enabled = false;
            this.pictureBox91.Location = new System.Drawing.Point(6, 408);
            this.pictureBox91.Name = "pictureBox91";
            this.pictureBox91.Size = new System.Drawing.Size(128, 128);
            this.pictureBox91.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox91.TabIndex = 62;
            this.pictureBox91.TabStop = false;
            this.pictureBox91.Click += new System.EventHandler(this.AccessorySellClick);
            // 
            // pictureBox92
            // 
            this.pictureBox92.BackColor = System.Drawing.Color.DimGray;
            this.pictureBox92.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.pictureBox92.Cursor = System.Windows.Forms.Cursors.Hand;
            this.pictureBox92.Enabled = false;
            this.pictureBox92.Location = new System.Drawing.Point(140, 408);
            this.pictureBox92.Name = "pictureBox92";
            this.pictureBox92.Size = new System.Drawing.Size(128, 128);
            this.pictureBox92.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox92.TabIndex = 63;
            this.pictureBox92.TabStop = false;
            this.pictureBox92.Click += new System.EventHandler(this.AccessorySellClick);
            // 
            // pictureBox93
            // 
            this.pictureBox93.BackColor = System.Drawing.Color.DimGray;
            this.pictureBox93.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.pictureBox93.Cursor = System.Windows.Forms.Cursors.Hand;
            this.pictureBox93.Enabled = false;
            this.pictureBox93.Location = new System.Drawing.Point(274, 408);
            this.pictureBox93.Name = "pictureBox93";
            this.pictureBox93.Size = new System.Drawing.Size(128, 128);
            this.pictureBox93.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox93.TabIndex = 64;
            this.pictureBox93.TabStop = false;
            this.pictureBox93.Click += new System.EventHandler(this.AccessorySellClick);
            // 
            // pictureBox94
            // 
            this.pictureBox94.BackColor = System.Drawing.Color.DimGray;
            this.pictureBox94.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.pictureBox94.Cursor = System.Windows.Forms.Cursors.Hand;
            this.pictureBox94.Enabled = false;
            this.pictureBox94.Location = new System.Drawing.Point(408, 408);
            this.pictureBox94.Name = "pictureBox94";
            this.pictureBox94.Size = new System.Drawing.Size(128, 128);
            this.pictureBox94.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox94.TabIndex = 65;
            this.pictureBox94.TabStop = false;
            this.pictureBox94.Click += new System.EventHandler(this.AccessorySellClick);
            // 
            // pictureBox95
            // 
            this.pictureBox95.BackColor = System.Drawing.Color.DimGray;
            this.pictureBox95.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.pictureBox95.Cursor = System.Windows.Forms.Cursors.Hand;
            this.pictureBox95.Enabled = false;
            this.pictureBox95.Location = new System.Drawing.Point(542, 408);
            this.pictureBox95.Name = "pictureBox95";
            this.pictureBox95.Size = new System.Drawing.Size(128, 128);
            this.pictureBox95.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox95.TabIndex = 66;
            this.pictureBox95.TabStop = false;
            this.pictureBox95.Click += new System.EventHandler(this.AccessorySellClick);
            // 
            // pictureBox86
            // 
            this.pictureBox86.BackColor = System.Drawing.Color.DimGray;
            this.pictureBox86.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.pictureBox86.Cursor = System.Windows.Forms.Cursors.Hand;
            this.pictureBox86.Enabled = false;
            this.pictureBox86.Location = new System.Drawing.Point(6, 274);
            this.pictureBox86.Name = "pictureBox86";
            this.pictureBox86.Size = new System.Drawing.Size(128, 128);
            this.pictureBox86.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox86.TabIndex = 57;
            this.pictureBox86.TabStop = false;
            this.pictureBox86.Click += new System.EventHandler(this.AccessorySellClick);
            // 
            // pictureBox87
            // 
            this.pictureBox87.BackColor = System.Drawing.Color.DimGray;
            this.pictureBox87.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.pictureBox87.Cursor = System.Windows.Forms.Cursors.Hand;
            this.pictureBox87.Enabled = false;
            this.pictureBox87.Location = new System.Drawing.Point(140, 274);
            this.pictureBox87.Name = "pictureBox87";
            this.pictureBox87.Size = new System.Drawing.Size(128, 128);
            this.pictureBox87.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox87.TabIndex = 58;
            this.pictureBox87.TabStop = false;
            this.pictureBox87.Click += new System.EventHandler(this.AccessorySellClick);
            // 
            // pictureBox88
            // 
            this.pictureBox88.BackColor = System.Drawing.Color.DimGray;
            this.pictureBox88.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.pictureBox88.Cursor = System.Windows.Forms.Cursors.Hand;
            this.pictureBox88.Enabled = false;
            this.pictureBox88.Location = new System.Drawing.Point(274, 274);
            this.pictureBox88.Name = "pictureBox88";
            this.pictureBox88.Size = new System.Drawing.Size(128, 128);
            this.pictureBox88.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox88.TabIndex = 59;
            this.pictureBox88.TabStop = false;
            this.pictureBox88.Click += new System.EventHandler(this.AccessorySellClick);
            // 
            // pictureBox89
            // 
            this.pictureBox89.BackColor = System.Drawing.Color.DimGray;
            this.pictureBox89.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.pictureBox89.Cursor = System.Windows.Forms.Cursors.Hand;
            this.pictureBox89.Enabled = false;
            this.pictureBox89.Location = new System.Drawing.Point(408, 274);
            this.pictureBox89.Name = "pictureBox89";
            this.pictureBox89.Size = new System.Drawing.Size(128, 128);
            this.pictureBox89.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox89.TabIndex = 60;
            this.pictureBox89.TabStop = false;
            this.pictureBox89.Click += new System.EventHandler(this.AccessorySellClick);
            // 
            // pictureBox90
            // 
            this.pictureBox90.BackColor = System.Drawing.Color.DimGray;
            this.pictureBox90.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.pictureBox90.Cursor = System.Windows.Forms.Cursors.Hand;
            this.pictureBox90.Enabled = false;
            this.pictureBox90.Location = new System.Drawing.Point(542, 274);
            this.pictureBox90.Name = "pictureBox90";
            this.pictureBox90.Size = new System.Drawing.Size(128, 128);
            this.pictureBox90.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox90.TabIndex = 61;
            this.pictureBox90.TabStop = false;
            this.pictureBox90.Click += new System.EventHandler(this.AccessorySellClick);
            // 
            // pictureBox81
            // 
            this.pictureBox81.BackColor = System.Drawing.Color.DimGray;
            this.pictureBox81.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.pictureBox81.Cursor = System.Windows.Forms.Cursors.Hand;
            this.pictureBox81.Enabled = false;
            this.pictureBox81.Location = new System.Drawing.Point(6, 140);
            this.pictureBox81.Name = "pictureBox81";
            this.pictureBox81.Size = new System.Drawing.Size(128, 128);
            this.pictureBox81.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox81.TabIndex = 52;
            this.pictureBox81.TabStop = false;
            this.pictureBox81.Click += new System.EventHandler(this.AccessorySellClick);
            // 
            // pictureBox82
            // 
            this.pictureBox82.BackColor = System.Drawing.Color.DimGray;
            this.pictureBox82.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.pictureBox82.Cursor = System.Windows.Forms.Cursors.Hand;
            this.pictureBox82.Enabled = false;
            this.pictureBox82.Location = new System.Drawing.Point(140, 140);
            this.pictureBox82.Name = "pictureBox82";
            this.pictureBox82.Size = new System.Drawing.Size(128, 128);
            this.pictureBox82.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox82.TabIndex = 53;
            this.pictureBox82.TabStop = false;
            this.pictureBox82.Click += new System.EventHandler(this.AccessorySellClick);
            // 
            // pictureBox83
            // 
            this.pictureBox83.BackColor = System.Drawing.Color.DimGray;
            this.pictureBox83.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.pictureBox83.Cursor = System.Windows.Forms.Cursors.Hand;
            this.pictureBox83.Enabled = false;
            this.pictureBox83.Location = new System.Drawing.Point(274, 140);
            this.pictureBox83.Name = "pictureBox83";
            this.pictureBox83.Size = new System.Drawing.Size(128, 128);
            this.pictureBox83.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox83.TabIndex = 54;
            this.pictureBox83.TabStop = false;
            this.pictureBox83.Click += new System.EventHandler(this.AccessorySellClick);
            // 
            // pictureBox84
            // 
            this.pictureBox84.BackColor = System.Drawing.Color.DimGray;
            this.pictureBox84.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.pictureBox84.Cursor = System.Windows.Forms.Cursors.Hand;
            this.pictureBox84.Enabled = false;
            this.pictureBox84.Location = new System.Drawing.Point(408, 140);
            this.pictureBox84.Name = "pictureBox84";
            this.pictureBox84.Size = new System.Drawing.Size(128, 128);
            this.pictureBox84.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox84.TabIndex = 55;
            this.pictureBox84.TabStop = false;
            this.pictureBox84.Click += new System.EventHandler(this.AccessorySellClick);
            // 
            // pictureBox85
            // 
            this.pictureBox85.BackColor = System.Drawing.Color.DimGray;
            this.pictureBox85.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.pictureBox85.Cursor = System.Windows.Forms.Cursors.Hand;
            this.pictureBox85.Enabled = false;
            this.pictureBox85.Location = new System.Drawing.Point(542, 140);
            this.pictureBox85.Name = "pictureBox85";
            this.pictureBox85.Size = new System.Drawing.Size(128, 128);
            this.pictureBox85.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox85.TabIndex = 56;
            this.pictureBox85.TabStop = false;
            this.pictureBox85.Click += new System.EventHandler(this.AccessorySellClick);
            // 
            // pictureBox76
            // 
            this.pictureBox76.BackColor = System.Drawing.Color.DimGray;
            this.pictureBox76.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.pictureBox76.Cursor = System.Windows.Forms.Cursors.Hand;
            this.pictureBox76.Enabled = false;
            this.pictureBox76.Location = new System.Drawing.Point(6, 6);
            this.pictureBox76.Name = "pictureBox76";
            this.pictureBox76.Size = new System.Drawing.Size(128, 128);
            this.pictureBox76.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox76.TabIndex = 47;
            this.pictureBox76.TabStop = false;
            this.pictureBox76.Click += new System.EventHandler(this.AccessorySellClick);
            // 
            // pictureBox77
            // 
            this.pictureBox77.BackColor = System.Drawing.Color.DimGray;
            this.pictureBox77.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.pictureBox77.Cursor = System.Windows.Forms.Cursors.Hand;
            this.pictureBox77.Enabled = false;
            this.pictureBox77.Location = new System.Drawing.Point(140, 6);
            this.pictureBox77.Name = "pictureBox77";
            this.pictureBox77.Size = new System.Drawing.Size(128, 128);
            this.pictureBox77.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox77.TabIndex = 48;
            this.pictureBox77.TabStop = false;
            this.pictureBox77.Click += new System.EventHandler(this.AccessorySellClick);
            // 
            // pictureBox78
            // 
            this.pictureBox78.BackColor = System.Drawing.Color.DimGray;
            this.pictureBox78.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.pictureBox78.Cursor = System.Windows.Forms.Cursors.Hand;
            this.pictureBox78.Enabled = false;
            this.pictureBox78.Location = new System.Drawing.Point(274, 6);
            this.pictureBox78.Name = "pictureBox78";
            this.pictureBox78.Size = new System.Drawing.Size(128, 128);
            this.pictureBox78.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox78.TabIndex = 49;
            this.pictureBox78.TabStop = false;
            this.pictureBox78.Click += new System.EventHandler(this.AccessorySellClick);
            // 
            // pictureBox79
            // 
            this.pictureBox79.BackColor = System.Drawing.Color.DimGray;
            this.pictureBox79.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.pictureBox79.Cursor = System.Windows.Forms.Cursors.Hand;
            this.pictureBox79.Enabled = false;
            this.pictureBox79.Location = new System.Drawing.Point(408, 6);
            this.pictureBox79.Name = "pictureBox79";
            this.pictureBox79.Size = new System.Drawing.Size(128, 128);
            this.pictureBox79.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox79.TabIndex = 50;
            this.pictureBox79.TabStop = false;
            this.pictureBox79.Click += new System.EventHandler(this.AccessorySellClick);
            // 
            // pictureBox80
            // 
            this.pictureBox80.BackColor = System.Drawing.Color.DimGray;
            this.pictureBox80.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.pictureBox80.Cursor = System.Windows.Forms.Cursors.Hand;
            this.pictureBox80.Enabled = false;
            this.pictureBox80.Location = new System.Drawing.Point(542, 6);
            this.pictureBox80.Name = "pictureBox80";
            this.pictureBox80.Size = new System.Drawing.Size(128, 128);
            this.pictureBox80.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox80.TabIndex = 51;
            this.pictureBox80.TabStop = false;
            this.pictureBox80.Click += new System.EventHandler(this.AccessorySellClick);
            // 
            // BackButton
            // 
            this.BackButton.BackColor = System.Drawing.Color.Black;
            this.BackButton.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.BackButton.ForeColor = System.Drawing.Color.Red;
            this.BackButton.Location = new System.Drawing.Point(23, 47);
            this.BackButton.Name = "BackButton";
            this.BackButton.Size = new System.Drawing.Size(339, 66);
            this.BackButton.TabIndex = 67;
            this.BackButton.TabStop = false;
            this.BackButton.Text = "Back to World";
            this.BackButton.UseVisualStyleBackColor = false;
            this.BackButton.Click += new System.EventHandler(this.BackButton_Click);
            // 
            // BuySellButton
            // 
            this.BuySellButton.BackColor = System.Drawing.Color.Black;
            this.BuySellButton.Enabled = false;
            this.BuySellButton.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.BuySellButton.ForeColor = System.Drawing.Color.Red;
            this.BuySellButton.Location = new System.Drawing.Point(23, 132);
            this.BuySellButton.Name = "BuySellButton";
            this.BuySellButton.Size = new System.Drawing.Size(339, 66);
            this.BuySellButton.TabIndex = 68;
            this.BuySellButton.TabStop = false;
            this.BuySellButton.Text = "Buy";
            this.BuySellButton.UseVisualStyleBackColor = false;
            this.BuySellButton.Click += new System.EventHandler(this.BuySellButton_Click);
            // 
            // label
            // 
            this.label.AutoSize = true;
            this.label.BackColor = System.Drawing.Color.Black;
            this.label.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label.ForeColor = System.Drawing.Color.Red;
            this.label.Location = new System.Drawing.Point(100, 218);
            this.label.Name = "label";
            this.label.Size = new System.Drawing.Size(106, 25);
            this.label.TabIndex = 69;
            this.label.Text = "Your gold: ";
            // 
            // GoldCountLabel
            // 
            this.GoldCountLabel.AutoSize = true;
            this.GoldCountLabel.BackColor = System.Drawing.Color.Black;
            this.GoldCountLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.GoldCountLabel.ForeColor = System.Drawing.Color.Red;
            this.GoldCountLabel.Location = new System.Drawing.Point(203, 218);
            this.GoldCountLabel.Name = "GoldCountLabel";
            this.GoldCountLabel.Size = new System.Drawing.Size(23, 25);
            this.GoldCountLabel.TabIndex = 70;
            this.GoldCountLabel.Text = "0";
            // 
            // Shop
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Black;
            this.ClientSize = new System.Drawing.Size(1447, 808);
            this.ControlBox = false;
            this.Controls.Add(this.GoldCountLabel);
            this.Controls.Add(this.label);
            this.Controls.Add(this.BuySellButton);
            this.Controls.Add(this.BackButton);
            this.Controls.Add(this.tabControl1);
            this.Controls.Add(this.ItemDescription);
            this.Controls.Add(this.ShopKeeperConversation);
            this.Controls.Add(this.ShopAnimation);
            this.KeyPreview = true;
            this.Name = "Shop";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Typical Adventure";
            this.Load += new System.EventHandler(this.Shop_Load);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox24)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox25)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox22)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox23)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox20)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox21)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox18)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox19)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox16)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox17)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox14)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox15)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox12)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox13)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox10)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox11)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox8)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox9)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox6)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox7)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox5)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.ShopAnimation)).EndInit();
            this.tabControl1.ResumeLayout(false);
            this.ShopItems.ResumeLayout(false);
            this.WeaponsSell.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox46)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox47)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox48)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox49)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox50)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox41)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox42)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox43)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox44)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox45)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox36)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox37)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox38)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox39)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox40)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox31)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox32)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox33)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox34)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox35)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox26)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox27)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox28)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox29)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox30)).EndInit();
            this.ArmorSell.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox71)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox72)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox73)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox74)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox75)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox66)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox67)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox68)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox69)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox70)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox61)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox62)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox63)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox64)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox65)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox56)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox57)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox58)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox59)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox60)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox51)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox52)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox53)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox54)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox55)).EndInit();
            this.AccessorySell.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox96)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox97)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox98)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox99)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox100)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox91)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox92)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox93)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox94)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox95)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox86)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox87)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox88)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox89)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox90)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox81)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox82)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox83)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox84)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox85)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox76)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox77)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox78)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox79)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox80)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.PictureBox pictureBox24;
        private System.Windows.Forms.PictureBox pictureBox25;
        private System.Windows.Forms.PictureBox pictureBox22;
        private System.Windows.Forms.PictureBox pictureBox23;
        private System.Windows.Forms.PictureBox pictureBox20;
        private System.Windows.Forms.PictureBox pictureBox21;
        private System.Windows.Forms.PictureBox pictureBox18;
        private System.Windows.Forms.PictureBox pictureBox19;
        private System.Windows.Forms.PictureBox pictureBox16;
        private System.Windows.Forms.PictureBox pictureBox17;
        private System.Windows.Forms.PictureBox pictureBox14;
        private System.Windows.Forms.PictureBox pictureBox15;
        private System.Windows.Forms.PictureBox pictureBox12;
        private System.Windows.Forms.PictureBox pictureBox13;
        private System.Windows.Forms.PictureBox pictureBox10;
        private System.Windows.Forms.PictureBox pictureBox11;
        private System.Windows.Forms.PictureBox pictureBox8;
        private System.Windows.Forms.PictureBox pictureBox9;
        private System.Windows.Forms.PictureBox pictureBox6;
        private System.Windows.Forms.PictureBox pictureBox7;
        private System.Windows.Forms.PictureBox pictureBox5;
        private System.Windows.Forms.PictureBox pictureBox4;
        private System.Windows.Forms.PictureBox pictureBox3;
        private System.Windows.Forms.PictureBox pictureBox2;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.PictureBox ShopAnimation;
        private System.Windows.Forms.RichTextBox ShopKeeperConversation;
        private System.Windows.Forms.RichTextBox ItemDescription;
        private System.Windows.Forms.TabControl tabControl1;
        private System.Windows.Forms.TabPage ShopItems;
        private System.Windows.Forms.TabPage WeaponsSell;
        private System.Windows.Forms.PictureBox pictureBox46;
        private System.Windows.Forms.PictureBox pictureBox47;
        private System.Windows.Forms.PictureBox pictureBox48;
        private System.Windows.Forms.PictureBox pictureBox49;
        private System.Windows.Forms.PictureBox pictureBox50;
        private System.Windows.Forms.PictureBox pictureBox41;
        private System.Windows.Forms.PictureBox pictureBox42;
        private System.Windows.Forms.PictureBox pictureBox43;
        private System.Windows.Forms.PictureBox pictureBox44;
        private System.Windows.Forms.PictureBox pictureBox45;
        private System.Windows.Forms.PictureBox pictureBox36;
        private System.Windows.Forms.PictureBox pictureBox37;
        private System.Windows.Forms.PictureBox pictureBox38;
        private System.Windows.Forms.PictureBox pictureBox39;
        private System.Windows.Forms.PictureBox pictureBox40;
        private System.Windows.Forms.PictureBox pictureBox31;
        private System.Windows.Forms.PictureBox pictureBox32;
        private System.Windows.Forms.PictureBox pictureBox33;
        private System.Windows.Forms.PictureBox pictureBox34;
        private System.Windows.Forms.PictureBox pictureBox35;
        private System.Windows.Forms.PictureBox pictureBox26;
        private System.Windows.Forms.PictureBox pictureBox27;
        private System.Windows.Forms.PictureBox pictureBox28;
        private System.Windows.Forms.PictureBox pictureBox29;
        private System.Windows.Forms.PictureBox pictureBox30;
        private System.Windows.Forms.Button BackButton;
        private System.Windows.Forms.Button BuySellButton;
        private System.Windows.Forms.TabPage ArmorSell;
        private System.Windows.Forms.PictureBox pictureBox71;
        private System.Windows.Forms.PictureBox pictureBox72;
        private System.Windows.Forms.PictureBox pictureBox73;
        private System.Windows.Forms.PictureBox pictureBox74;
        private System.Windows.Forms.PictureBox pictureBox75;
        private System.Windows.Forms.PictureBox pictureBox66;
        private System.Windows.Forms.PictureBox pictureBox67;
        private System.Windows.Forms.PictureBox pictureBox68;
        private System.Windows.Forms.PictureBox pictureBox69;
        private System.Windows.Forms.PictureBox pictureBox70;
        private System.Windows.Forms.PictureBox pictureBox61;
        private System.Windows.Forms.PictureBox pictureBox62;
        private System.Windows.Forms.PictureBox pictureBox63;
        private System.Windows.Forms.PictureBox pictureBox64;
        private System.Windows.Forms.PictureBox pictureBox65;
        private System.Windows.Forms.PictureBox pictureBox56;
        private System.Windows.Forms.PictureBox pictureBox57;
        private System.Windows.Forms.PictureBox pictureBox58;
        private System.Windows.Forms.PictureBox pictureBox59;
        private System.Windows.Forms.PictureBox pictureBox60;
        private System.Windows.Forms.PictureBox pictureBox51;
        private System.Windows.Forms.PictureBox pictureBox52;
        private System.Windows.Forms.PictureBox pictureBox53;
        private System.Windows.Forms.PictureBox pictureBox54;
        private System.Windows.Forms.PictureBox pictureBox55;
        private System.Windows.Forms.TabPage AccessorySell;
        private System.Windows.Forms.PictureBox pictureBox96;
        private System.Windows.Forms.PictureBox pictureBox97;
        private System.Windows.Forms.PictureBox pictureBox98;
        private System.Windows.Forms.PictureBox pictureBox99;
        private System.Windows.Forms.PictureBox pictureBox100;
        private System.Windows.Forms.PictureBox pictureBox91;
        private System.Windows.Forms.PictureBox pictureBox92;
        private System.Windows.Forms.PictureBox pictureBox93;
        private System.Windows.Forms.PictureBox pictureBox94;
        private System.Windows.Forms.PictureBox pictureBox95;
        private System.Windows.Forms.PictureBox pictureBox86;
        private System.Windows.Forms.PictureBox pictureBox87;
        private System.Windows.Forms.PictureBox pictureBox88;
        private System.Windows.Forms.PictureBox pictureBox89;
        private System.Windows.Forms.PictureBox pictureBox90;
        private System.Windows.Forms.PictureBox pictureBox81;
        private System.Windows.Forms.PictureBox pictureBox82;
        private System.Windows.Forms.PictureBox pictureBox83;
        private System.Windows.Forms.PictureBox pictureBox84;
        private System.Windows.Forms.PictureBox pictureBox85;
        private System.Windows.Forms.PictureBox pictureBox76;
        private System.Windows.Forms.PictureBox pictureBox77;
        private System.Windows.Forms.PictureBox pictureBox78;
        private System.Windows.Forms.PictureBox pictureBox79;
        private System.Windows.Forms.PictureBox pictureBox80;
        private System.Windows.Forms.Label label;
        private System.Windows.Forms.Label GoldCountLabel;
    }
}